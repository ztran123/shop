<?php
/**
* @Mã Nguồn    Viết Bởi Hoàng Anh
* @Trang Web   hostingsieure.com
* @Liên Hệ     https://facebook.com/hoanganh.180599na
* @Điện thoại  0856617819
* @Zalo        0856617819
* @Email       hoanganh18595@gmail.com
*/
?>
</main>
</div>
<footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
<div class="pull-right">
Thiết kế <i class="fa fa-heart text-city"></i> bởi <a class="font-w600" href="https://facebook.com/hoanganh.180599na" target="_blank">Hoàng Anh</a>
</div>
<div class="pull-left">Phát triển 2019
</div>
</footer>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/bootstrap.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.sparkline.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.easypiechart.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/base_ui_widgets.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/slick.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.slimscroll.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.scrollLock.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.appear.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.countTo.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/jquery.placeholder.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/js.cookie.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/bootstrap3-typeahead.min.js"></script>
<script src="<?php echo $trangchu; ?>/danhmuc_giaodien/quantri/javascript/magnific-popup.min.js"></script>
