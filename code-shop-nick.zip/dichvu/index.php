<?php
header('location: /404');
?>